const i="English is not my first language, so I often write rough messages and want them rewritten naturally. I prefer friendly, clear, respectful, and practical communication.",l=`Preserve my original meaning.
Do not add fake details.
Make the text grammatically correct and easy to understand.
Keep the message human, warm, and direct.
Use simple natural English.
Keep the output suitable for the same context.`,c=`Avoid robotic language.
Avoid unnecessary fancy words.
Avoid over-apologizing.
Avoid exaggerated compliments.
Avoid emojis unless my original text already has emojis.
Avoid phrases like I hope this message finds you well.
Avoid changing the emotional meaning.
Avoid making short casual messages sound like corporate emails.`,g="normal",o={aiChatUrl:"",aboutMe:i,globalPrompt:l,avoidPrompt:c,defaultMode:g,autoOpenAiTab:!1,buttonPosition:"auto",enableOnAllSites:!0,disabledSites:[]},t="settings";function r(){var e;return(e=chrome.storage)!=null&&e.sync?chrome.storage.sync:chrome.storage.local}async function m(){const n=(await r().get(t))[t];return{...o,...n??{}}}async function d(e){await r().set({[t]:e})}async function h(){return await d(o),{...o}}function f(e){const a=(n,u)=>{if(n[t]){const s=n[t].newValue;s&&e({...o,...s})}};return chrome.storage.onChanged.addListener(a),()=>chrome.storage.onChanged.removeListener(a)}export{o as D,m as l,f as o,h as r,d as s};
//# sourceMappingURL=storage-C8pLM0lv.js.map
